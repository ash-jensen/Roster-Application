#pragma once
#include <iostream>
#include <string>
using namespace std;

// Enumeration Degree Program types
enum DegreeProgram { SECURITY, NETWORK, SOFTWARE };

// Parallel array of Degree Types
static string degreeProgramStrings[] = { "Security", "Network", "Software" };

